import { useState, useEffect } from 'react';
import { AppProvider, useApp } from '@/context/AppContext';
import { Sidebar } from '@/components/Sidebar';
import { Toast } from '@/components/ui/Toast';
import { ProjectFormModal } from '@/components/modals/ProjectFormModal';
import { AccountFormModal } from '@/components/modals/AccountFormModal';
import { ContactFormModal } from '@/components/modals/ContactFormModal';
import { ActivityFormModal } from '@/components/modals/ActivityFormModal';
import { OpportunityFormModal } from '@/components/modals/OpportunityFormModal';
import { ImportCSVModal } from '@/components/modals/ImportCSVModal';
import { DashboardView } from '@/views/DashboardView';
import { PipelineView } from '@/views/PipelineView';
import { ProjectsView } from '@/views/ProjectsView';
import { ProjectDetail } from '@/views/ProjectDetail';
import { AccountsView } from '@/views/AccountsView';
import { AccountDetail } from '@/views/AccountDetail';
import { ContactsView } from '@/views/ContactsView';
import { ContactDetail } from '@/views/ContactDetail';
import { ActivitiesView } from '@/views/ActivitiesView';
import { SettingsView } from '@/views/SettingsView';
import { TenantAdminView } from '@/views/TenantAdminView';
import { OnboardingModal } from '@/components/modals/OnboardingModal';
import { GlobalSearch } from '@/components/GlobalSearch';
import { LandingPage } from '@/components/LandingPage';
import { SubscriptionBlocked } from '@/components/SubscriptionBlocked';
import { loadTenantConfig, hasDedicatedTenant, isCrmPymeBuild, getTenantConfig, checkTenantSubscription, type TenantsConfigFile } from '@/config/tenantConfig';
import './index.css';

function AppContent() {
  const { state } = useApp();
  const renderView = () => {
    switch (state.activeView) {
      case 'dashboard': return <DashboardView />;
      case 'pipeline': return <PipelineView />;
      case 'projects': return <ProjectsView />;
      case 'project-detail': return <ProjectDetail />;
      case 'accounts': return <AccountsView />;
      case 'account-detail': return <AccountDetail />;
      case 'contacts': return <ContactsView />;
      case 'contact-detail': return <ContactDetail />;
      case 'activities': return <ActivitiesView />;
      case 'settings': return <SettingsView />;
      case 'tenant-admin': return <TenantAdminView />;
      default: return <DashboardView />;
    }
  };
  return (
    <div className="min-h-screen bg-[#181A20]">
      <Sidebar />
      <div className="md:ml-[280px] min-h-screen">
        <main className="p-5 sm:p-7 lg:p-10 max-w-[1440px] mx-auto">
          {renderView()}
        </main>
      </div>
      <OpportunityFormModal />
      <ProjectFormModal />
      <AccountFormModal />
      <ContactFormModal />
      <ActivityFormModal />
      <Toast />
      {state.modalOpen === 'import-csv' && <ImportCSVModal />}
      <GlobalSearch />
      <OnboardingModal />
    </div>
  );
}

function App() {
  const [tenantsFile, setTenantsFile] = useState<TenantsConfigFile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTenantConfig().then((config) => {
      setTenantsFile(config);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#181A20] flex items-center justify-center">
        <div className="text-center">
          <div className="w-10 h-10 border-2 border-[#D4A824] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-sm text-[#6B7280]">Cargando...</p>
        </div>
      </div>
    );
  }

  // INGEFIX build: always show the CRM, no landing page
  if (!isCrmPymeBuild()) {
    return (
      <AppProvider>
        <AppContent />
      </AppProvider>
    );
  }

  // CRM-PyME build: check if this hostname has a dedicated tenant
  const hasTenant = tenantsFile ? hasDedicatedTenant(tenantsFile) : false;

  // If no dedicated tenant, show generic landing page (not the CRM)
  if (!hasTenant) {
    return <LandingPage />;
  }

  // This hostname HAS a tenant config — check if subscription is active
  const tenant = tenantsFile ? getTenantConfig(tenantsFile) : null;
  const subscription = tenant ? checkTenantSubscription(tenant) : { active: true };

  if (!subscription.active && tenant) {
    return (
      <SubscriptionBlocked
        reason={subscription.reason!}
        tenantName={tenant.name}
        expiryDate={tenant.expiresAt}
        contactEmail={tenant.contactEmail}
      />
    );
  }

  return (
    <AppProvider initialTenantConfig={tenant}>
      <AppContent />
    </AppProvider>
  );
}

export default App;
