import { useState } from 'react';
import { isCrmPymeBuild, setOnboardingConfig, type OnboardingConfig } from '@/config/tenantConfig';
import { useApp } from '@/context/AppContext';
import { Rocket, User, Building2, Database, Sparkles, CheckCircle, ChevronRight } from 'lucide-react';

export function OnboardingModal() {
  const { state } = useApp();
  const tenant = state.tenantConfig;
  const branding = tenant || { name: 'CRM-PyME', tagline: 'Gestión Comercial para PYMEs' };
  const [step, setStep] = useState(1);
  const [companyName, setCompanyName] = useState('');
  const [userName, setUserName] = useState('');
  const [useDemoData, setUseDemoData] = useState(true);
  const [isCompleting, setIsCompleting] = useState(false);

  // Si ya hay datos o no es CRM-PyME, no mostrar
  if (!isCrmPymeBuild() || state.accounts.length > 0 || state.contacts.length > 0) {
    return null;
  }

  const handleComplete = () => {
    setIsCompleting(true);
    const config: OnboardingConfig = {
      companyName: companyName.trim() || 'Mi Empresa',
      userName: userName.trim() || 'Usuario',
      useDemoData,
      completedAt: new Date().toISOString(),
    };
    setOnboardingConfig(config);
    // Recargar datos según elección
    window.location.reload();
  };

  return (
    <div className="fixed inset-0 z-[100] bg-[#181A20] flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-[#1E2028] border border-[#2A2D3A] rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#D4A824]/10 to-transparent px-8 py-6 border-b border-[#2A2D3A]">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-[#D4A824]/20 flex items-center justify-center">
              <Rocket className="w-5 h-5 text-[#D4A824]" />
            </div>
            <h1 className="text-2xl font-bold text-[#F0F2F5]">{branding.name}</h1>
          </div>
          <p className="text-sm text-[#6B7280]">{branding.tagline}</p>
        </div>

        {/* Steps */}
        <div className="px-8 py-6">
          {step === 1 && (
            <div className="space-y-6">
              <div className="text-center space-y-3">
                <h2 className="text-xl font-semibold text-[#F0F2F5]">Bienvenido</h2>
                <p className="text-sm text-[#6B7280] leading-relaxed">
                  Configura tu CRM en menos de un minuto. Todo queda guardado en tu navegador, sin necesidad de internet ni registro.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl bg-[#181A20] border border-[#2A2D3A] text-center space-y-2">
                  <Database className="w-6 h-6 text-[#D4A824] mx-auto" />
                  <p className="text-xs text-[#9CA3AF]">100% offline</p>
                </div>
                <div className="p-4 rounded-xl bg-[#181A20] border border-[#2A2D3A] text-center space-y-2">
                  <Sparkles className="w-6 h-6 text-[#D4A824] mx-auto" />
                  <p className="text-xs text-[#9CA3AF]">Ultra sencillo</p>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-5">
              <div className="text-center space-y-2">
                <h2 className="text-xl font-semibold text-[#F0F2F5]">Cuéntanos de ti</h2>
                <p className="text-sm text-[#6B7280]">Personalizaremos tu espacio de trabajo</p>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-[#9CA3AF] mb-1.5">
                    <Building2 className="w-4 h-4 inline mr-1.5 -mt-0.5" />
                    Nombre de tu empresa
                  </label>
                  <input
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Ej: Constructora del Sur"
                    className="w-full px-4 py-2.5 bg-[#181A20] border border-[#2A2D3A] rounded-lg text-[#F0F2F5] placeholder-[#4B5563] focus:outline-none focus:border-[#D4A824]/50 focus:ring-1 focus:ring-[#D4A824]/20 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#9CA3AF] mb-1.5">
                    <User className="w-4 h-4 inline mr-1.5 -mt-0.5" />
                    Tu nombre
                  </label>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Ej: Juan Pérez"
                    className="w-full px-4 py-2.5 bg-[#181A20] border border-[#2A2D3A] rounded-lg text-[#F0F2F5] placeholder-[#4B5563] focus:outline-none focus:border-[#D4A824]/50 focus:ring-1 focus:ring-[#D4A824]/20 transition-all"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-5">
              <div className="text-center space-y-2">
                <h2 className="text-xl font-semibold text-[#F0F2F5]">¿Cómo empezar?</h2>
                <p className="text-sm text-[#6B7280]">Elige la opción que prefieras</p>
              </div>
              <div className="space-y-3">
                <button
                  onClick={() => setUseDemoData(true)}
                  className={`w-full p-4 rounded-xl border text-left transition-all ${
                    useDemoData
                      ? 'border-[#D4A824]/50 bg-[#D4A824]/10 ring-1 ring-[#D4A824]/20'
                      : 'border-[#2A2D3A] bg-[#181A20] hover:border-[#3A3D4A]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 mt-0.5 flex items-center justify-center flex-shrink-0 ${
                      useDemoData ? 'border-[#D4A824] bg-[#D4A824]' : 'border-[#4B5563]'
                    }`}>
                      {useDemoData && <CheckCircle className="w-3.5 h-3.5 text-[#181A20]" />}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#F0F2F5]">Ver con datos de ejemplo</p>
                      <p className="text-xs text-[#6B7280] mt-1">Carga proyectos, cuentas y oportunidades de prueba para que explores el CRM antes de borrarlos.</p>
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => setUseDemoData(false)}
                  className={`w-full p-4 rounded-xl border text-left transition-all ${
                    !useDemoData
                      ? 'border-[#D4A824]/50 bg-[#D4A824]/10 ring-1 ring-[#D4A824]/20'
                      : 'border-[#2A2D3A] bg-[#181A20] hover:border-[#3A3D4A]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 mt-0.5 flex items-center justify-center flex-shrink-0 ${
                      !useDemoData ? 'border-[#D4A824] bg-[#D4A824]' : 'border-[#4B5563]'
                    }`}>
                      {!useDemoData && <CheckCircle className="w-3.5 h-3.5 text-[#181A20]" />}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#F0F2F5]">Empezar desde cero</p>
                      <p className="text-xs text-[#6B7280] mt-1">CRM vacío. Tú ingresas tus clientes, contactos y oportunidades.</p>
                    </div>
                  </div>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-8 py-5 border-t border-[#2A2D3A] flex items-center justify-between">
          <div className="flex gap-1.5">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`w-2 h-2 rounded-full transition-colors ${
                  s === step ? 'bg-[#D4A824]' : s < step ? 'bg-[#D4A824]/50' : 'bg-[#2A2D3A]'
                }`}
              />
            ))}
          </div>

          <div className="flex gap-3">
            {step > 1 && (
              <button
                onClick={() => setStep(step - 1)}
                className="px-4 py-2 text-sm text-[#9CA3AF] hover:text-[#F0F2F5] transition-colors"
              >
                Atrás
              </button>
            )}
            {step < 3 ? (
              <button
                onClick={() => setStep(step + 1)}
                className="px-5 py-2 bg-[#D4A824] hover:bg-[#E8C545] text-[#181A20] text-sm font-semibold rounded-lg transition-colors flex items-center gap-1.5"
              >
                Continuar
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleComplete}
                disabled={isCompleting}
                className="px-5 py-2 bg-[#D4A824] hover:bg-[#E8C545] text-[#181A20] text-sm font-semibold rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
              >
                {isCompleting ? 'Configurando...' : 'Comenzar'}
                <Rocket className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
