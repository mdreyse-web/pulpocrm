import { useState } from 'react';
import { Building2, Mail, MessageSquare, ArrowRight } from 'lucide-react';

export function LandingPage() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const hostname = window.location.hostname;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubmitted(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#181A20] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md text-center">
        {/* Logo placeholder */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#D4A824] to-[#E8C545] flex items-center justify-center mx-auto mb-6 shadow-lg shadow-[#D4A824]/20">
          <Building2 className="w-8 h-8 text-[#181A20]" />
        </div>

        <h1 className="text-3xl font-bold text-[#F0F2F5] mb-2">
          CRM-PyME
        </h1>
        <p className="text-[#6B7280] mb-8">
          Gestión comercial simplificada para PYMEs
        </p>

        <div className="bg-[#1E2028] border border-[#2A2D3A] rounded-2xl p-8 mb-6">
          <div className="w-12 h-12 rounded-full bg-[#D4A824]/10 flex items-center justify-center mx-auto mb-4">
            <MessageSquare className="w-6 h-6 text-[#D4A824]" />
          </div>
          <h2 className="text-xl font-semibold text-[#F0F2F5] mb-2">
            Espacio disponible
          </h2>
          <p className="text-sm text-[#6B7280] mb-6">
            El subdominio <span className="text-[#D4A824] font-mono">{hostname}</span> está reservado para un cliente de CRM-PyME.
          </p>
          <p className="text-sm text-[#6B7280]">
            Si eres el propietario, contacta a tu administrador para activar tu cuenta.
          </p>
        </div>

        <div className="bg-[#1E2028] border border-[#2A2D3A] rounded-2xl p-6">
          <h3 className="text-sm font-medium text-[#9CA3AF] mb-4 flex items-center justify-center gap-2">
            <Mail className="w-4 h-4" />
            ¿Te interesa este CRM para tu empresa?
          </h3>
          {submitted ? (
            <div className="text-sm text-[#22C55E]">
              Gracias, te contactaremos pronto.
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex gap-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="tu@empresa.cl"
                className="flex-1 px-4 py-2.5 bg-[#181A20] border border-[#2A2D3A] rounded-lg text-sm text-[#F0F2F5] placeholder-[#4B5563] focus:outline-none focus:border-[#D4A824]/50"
                required
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-[#D4A824] hover:bg-[#E8C545] text-[#181A20] text-sm font-semibold rounded-lg transition-colors flex items-center gap-1.5"
              >
                Enviar
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>

        <p className="text-xs text-[#4B5563] mt-8">
          Potenciado por CRM-PyME
        </p>
      </div>
    </div>
  );
}
