import { useState, useRef } from 'react';
import { Database, Upload, FileJson, FileSpreadsheet, Trash2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useApp } from '@/context/AppContext';

type SettingsTab = 'data' | 'sheets';

export const SettingsView: React.FC = () => {
  const { state, exportToJSON, exportToCSV, importFromJSON, resetAllData, showToast, openModal } = useApp();
  const [activeTab, setActiveTab] = useState<SettingsTab>('data');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [importPreview, setImportPreview] = useState<{
    opportunities: number;
    projects: number;
    accounts: number;
    contacts: number;
    activities: number;
  } | null>(null);
  const [pendingImport, setPendingImport] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target?.result as string);
        const counts = {
          opportunities: (data.opportunities || []).length,
          projects: (data.projects || []).length,
          accounts: (data.accounts || []).length,
          contacts: (data.contacts || []).length,
          activities: (data.activities || []).length,
        };
        setImportPreview(counts);
        setPendingImport(ev.target?.result as string);
      } catch {
        showToast('El archivo no es un JSON válido', 'error');
      }
    };
    reader.readAsText(file);
  };

  const confirmImport = () => {
    if (!pendingImport) return;
    try {
      const data = JSON.parse(pendingImport);
      const migratedAccounts = (data.accounts || []).map((a: any) => {
        if (a.projectIds !== undefined) return a;
        if (a.projectId) return { ...a, projectIds: [a.projectId] };
        return { ...a, projectIds: [] };
      });
      const migratedProjects = (data.projects || []).map((p: any) => ({
        status: p.status || 'active',
        location: p.location || '',
        startDate: p.startDate || new Date().toISOString(),
        endDate: p.endDate || null,
        budget: p.budget || null,
        ...p,
      }));
      const migratedOpportunities = (data.opportunities || []).map((o: any) => ({
        projectId: o.projectId ?? null,
        lossReason: o.lossReason || '',
        notes: o.notes || '',
        priority: o.priority || 'medium',
        expectedCloseDate: o.expectedCloseDate ?? null,
        actualCloseDate: o.actualCloseDate ?? null,
        ...o,
      }));
      importFromJSON({
        opportunities: migratedOpportunities,
        projects: migratedProjects,
        accounts: migratedAccounts,
        contacts: data.contacts || [],
        activities: data.activities || [],
      });
      setImportPreview(null);
      setPendingImport(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch {
      showToast('Error al importar datos', 'error');
    }
  };

  const tabs = [
    { key: 'data' as SettingsTab, label: 'Datos', icon: Database },
    { key: 'sheets' as SettingsTab, label: 'Google Sheets', icon: FileSpreadsheet },
  ];

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-[#F0F2F5]">Configuración</h2>
        <p className="text-sm text-[#6B7280] mt-1">Gestiona tus datos y sincronización</p>
      </div>
      <div className="flex gap-1 border-b border-[#25282F] mb-6">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)} className={`flex items-center gap-2 px-5 py-3 text-sm font-medium transition-colors border-b-2 ${activeTab === tab.key ? 'text-[#D4A824] border-[#D4A824]' : 'text-[#A0A8B8] border-transparent hover:text-[#F0F2F5]'}`}>
              <Icon size={16} /> {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'data' && (
        <div className="space-y-6 max-w-2xl">
          <div className="bg-[#22252D] border border-[#2E323A] rounded-xl p-6">
            <h3 className="text-base font-semibold text-[#F0F2F5] mb-1">Exportar Datos</h3>
            <p className="text-sm text-[#6B7280] mb-5">Descarga tus datos en diferentes formatos para respaldo o análisis.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Button variant="secondary" leftIcon={<FileJson size={16} />} onClick={exportToJSON}>Exportar a JSON (Backup)</Button>
              <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('opportunities')}>Exportar Pipeline CSV</Button>
              <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('projects')}>Exportar Proyectos CSV</Button>
              <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('accounts')}>Exportar Cuentas CSV</Button>
              <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('contacts')}>Exportar Contactos CSV</Button>
              <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('activities')}>Exportar Actividades CSV</Button>
            </div>
          </div>

          <div className="bg-[#22252D] border border-[#2E323A] rounded-xl p-6">
            <h3 className="text-base font-semibold text-[#F0F2F5] mb-1">Importar Datos</h3>
            <p className="text-sm text-[#6B7280] mb-5">Importa datos desde un archivo JSON previamente exportado. Compatible con backups anteriores.</p>
            <input ref={fileInputRef} type="file" accept=".json" onChange={handleFileSelect} className="hidden" />
            <div className="flex flex-wrap gap-3">
              <Button variant="secondary" leftIcon={<Upload size={16} />} onClick={() => fileInputRef.current?.click()}>Seleccionar archivo JSON</Button>
              <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => openModal('import-csv')}>Importar desde Excel/CSV</Button>
            </div>

            {importPreview && (
              <div className="mt-4 p-4 bg-[#1E2128] rounded-lg border border-[#2E323A]">
                <p className="text-sm text-[#A0A8B8] mb-3">Se importarán:</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
                  {importPreview.opportunities > 0 && <span className="text-sm text-[#F0F2F5]"><strong>{importPreview.opportunities}</strong> oportunidades</span>}
                  <span className="text-sm text-[#F0F2F5]"><strong>{importPreview.projects}</strong> proyectos</span>
                  <span className="text-sm text-[#F0F2F5]"><strong>{importPreview.accounts}</strong> cuentas</span>
                  <span className="text-sm text-[#F0F2F5]"><strong>{importPreview.contacts}</strong> contactos</span>
                  <span className="text-sm text-[#F0F2F5]"><strong>{importPreview.activities}</strong> actividades</span>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={confirmImport}>Confirmar Importación</Button>
                  <Button size="sm" variant="ghost" onClick={() => { setImportPreview(null); setPendingImport(null); }}>Cancelar</Button>
                </div>
              </div>
            )}
          </div>

          <div className="bg-[#22252D] border border-[#EF4444]/30 rounded-xl p-6">
            <h3 className="text-base font-semibold text-[#EF4444] mb-1 flex items-center gap-2"><AlertTriangle size={18} /> Zona de Peligro</h3>
            <p className="text-sm text-[#6B7280] mb-5">Estas acciones son irreversibles.</p>
            {!showDeleteConfirm ? (
              <Button variant="danger" leftIcon={<Trash2 size={16} />} onClick={() => setShowDeleteConfirm(true)}>Borrar Todos los Datos</Button>
            ) : (
              <div className="p-4 bg-[#EF4444]/10 rounded-lg border border-[#EF4444]/30">
                <p className="text-sm text-[#EF4444] mb-3">¿Eliminar permanentemente todos los datos?</p>
                <div className="flex gap-2">
                  <Button size="sm" variant="danger" onClick={() => { resetAllData(); setShowDeleteConfirm(false); }}>Sí, borrar todo</Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowDeleteConfirm(false)}>Cancelar</Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'sheets' && (
        <div className="max-w-2xl">
          <div className="bg-[#22252D] border border-[#2E323A] rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-[#22C55E15] flex items-center justify-center"><FileSpreadsheet size={20} className="text-[#22C55E]" /></div>
              <div>
                <h3 className="text-base font-semibold text-[#F0F2F5]">Sincronización con Google Sheets</h3>
                <p className="text-sm text-[#6B7280]">Exporta tus datos a CSV y luego impórtalos a Google Sheets</p>
              </div>
            </div>
            <div className="space-y-4 mt-6">
              <div className="p-4 bg-[#1E2128] rounded-lg border border-[#2E323A]">
                <h4 className="text-sm font-semibold text-[#F0F2F5] mb-3">Instrucciones:</h4>
                <ol className="space-y-3 text-sm text-[#A0A8B8]">
                  <li className="flex items-start gap-2"><span className="flex-shrink-0 w-5 h-5 rounded-full bg-[#D4A82415] text-[#D4A824] flex items-center justify-center text-xs font-semibold">1</span><span>Exporta a CSV desde la pestaña "Datos".</span></li>
                  <li className="flex items-start gap-2"><span className="flex-shrink-0 w-5 h-5 rounded-full bg-[#D4A82415] text-[#D4A824] flex items-center justify-center text-xs font-semibold">2</span><span>Abre Google Sheets y ve a <strong>Archivo &gt; Importar</strong>.</span></li>
                  <li className="flex items-start gap-2"><span className="flex-shrink-0 w-5 h-5 rounded-full bg-[#D4A82415] text-[#D4A824] flex items-center justify-center text-xs font-semibold">3</span><span>Usa separador de coma y codificación UTF-8.</span></li>
                </ol>
              </div>
              <div className="flex flex-wrap gap-3">
                <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('opportunities')}>Pipeline CSV</Button>
                <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('projects')}>Proyectos CSV</Button>
                <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('accounts')}>Cuentas CSV</Button>
                <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('contacts')}>Contactos CSV</Button>
                <Button variant="secondary" leftIcon={<FileSpreadsheet size={16} />} onClick={() => exportToCSV('activities')}>Actividades CSV</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
