import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"
import { inspectAttr } from 'kimi-plugin-inspect-react'

const brand = process.env.VITE_BRAND || 'ingefix';

// https://vite.dev/config/
export default defineConfig({
  base: './',
  define: {
    __CRM_BRAND__: JSON.stringify(brand),
  },
  plugins: [inspectAttr(), react()],
  server: {
    port: 3000,
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
});
